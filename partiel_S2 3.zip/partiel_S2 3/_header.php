<?php
require 'database.php';
require 'panier.class.php';

$DB = new DB();
$panier = new panier($DB);


?>